"""Home page for the Streamlit medical diffusion frontend."""

from __future__ import annotations

import streamlit as st

from medical_diffusion_app.configs.config import EFFICIENTNET_BACKBONE, GRADCAM_TARGET_LAYER, PROJECT_TITLE


def render_home_page() -> None:
    """Shows the project overview and architecture summary."""
    st.title("Medical Synthetic Data Generation")
    st.caption(PROJECT_TITLE)

    st.markdown(
        """
        This small fullstack project separates the user interface, backend API, and diffusion model pipeline.
        The structure is intentionally simple so it is easy to review in VS Code and easy to explain in a project demo.
        """
    )

    col1, col2 = st.columns(2)
    with col1:
        st.markdown("### Fullstack flow")
        st.markdown(
            """
            1. Frontend selects a disease label and sample count.
            2. FastAPI receives the generation request.
            3. The ML layer runs conditional diffusion generation.
            4. Outputs are saved to `outputs/synthetic_data/` and previewed in Streamlit.
            """
        )
    with col2:
        st.markdown("### Integration ready")
        st.markdown(
            f"""
            - EfficientNet integration: `{EFFICIENTNET_BACKBONE}`
            - Grad-CAM hook target: `{GRADCAM_TARGET_LAYER}`
            - Output folders keep checkpoints, previews, logs, and synthetic data separate.
            """
        )

