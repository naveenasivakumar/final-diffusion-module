"""Shared helpers used by the frontend, backend, and ML layers."""

from __future__ import annotations

import json
import random
from datetime import datetime
from pathlib import Path
from typing import Any

try:
    import matplotlib.pyplot as plt
except ModuleNotFoundError:
    plt = None

try:
    import numpy as np
except ModuleNotFoundError:
    np = None

try:
    from PIL import Image
except ModuleNotFoundError:
    Image = None

try:
    import torch
except ModuleNotFoundError:
    torch = None

try:
    from torchvision.utils import make_grid
except ModuleNotFoundError:
    make_grid = None

from medical_diffusion_app.configs.config import CHECKPOINT_DIR, CLASS_NAMES, LOG_DIR, LOSS_PLOT_PATH, PREVIEW_DIR, SYNTHETIC_DATA_DIR


def _require_dependency(module: Any, package_name: str) -> None:
    """Raises a clear error when an optional dependency is missing."""
    if module is None:
        raise ModuleNotFoundError(
            f"{package_name} is required for this operation. Install ML dependencies with "
            "`pip install -r medical_diffusion_app/requirements-ml.txt`."
        )


def set_seed(seed: int) -> None:
    """Sets seeds for repeatable experimentation."""
    random.seed(seed)
    if np is not None:
        np.random.seed(seed)
    if torch is not None:
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)


def get_device() -> Any:
    """Returns the best available device for PyTorch."""
    if torch is None:
        return "cpu"
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def ensure_output_dirs() -> dict[str, Path]:
    """Creates the output folders used across the project."""
    folders = {
        "checkpoints": CHECKPOINT_DIR,
        "previews": PREVIEW_DIR,
        "synthetic_data": SYNTHETIC_DATA_DIR,
        "logs": LOG_DIR,
    }
    for folder in folders.values():
        folder.mkdir(parents=True, exist_ok=True)
    return folders


def denormalize(image_tensor: Any) -> Any:
    """Converts tensors from [-1, 1] to [0, 1] for saving."""
    _require_dependency(torch, "torch")
    return image_tensor.detach().clamp(-1.0, 1.0).add(1.0).div(2.0)


def timestamp_slug() -> str:
    """Returns a filesystem-safe timestamp string."""
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def save_checkpoint(
    checkpoint_path: str | Path,
    model: Any,
    optimizer: Any,
    epoch: int,
    loss: float,
    best_val_loss: float,
    history: list[float],
    scaler: Any | None = None,
    extra_state: dict[str, Any] | None = None,
) -> Path:
    """Saves model and optimizer state for resume or inference."""
    _require_dependency(torch, "torch")
    checkpoint_path = Path(checkpoint_path)
    checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
    payload: dict[str, Any] = {
        "epoch": epoch,
        "loss": loss,
        "best_val_loss": best_val_loss,
        "history": history,
        "model_state_dict": model.state_dict(),
        "optimizer_state_dict": optimizer.state_dict(),
        "scaler_state_dict": scaler.state_dict() if scaler is not None else None,
    }
    if extra_state:
        payload.update(extra_state)
    torch.save(payload, checkpoint_path)
    return checkpoint_path


def load_checkpoint(
    checkpoint_path: str | Path,
    model: Any,
    optimizer: Any | None = None,
    device: Any = "cpu",
    scaler: Any | None = None,
) -> dict[str, Any]:
    """Loads a saved checkpoint into model and optional optimizer."""
    _require_dependency(torch, "torch")
    checkpoint_path = Path(checkpoint_path)
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Checkpoint not found: {checkpoint_path}")

    checkpoint = torch.load(checkpoint_path, map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])
    if optimizer is not None and checkpoint.get("optimizer_state_dict") is not None:
        optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
    if scaler is not None and checkpoint.get("scaler_state_dict") is not None:
        scaler.load_state_dict(checkpoint["scaler_state_dict"])
    return checkpoint


def save_preview(
    images: Any,
    output_path: str | Path,
    nrow: int | None = None,
    caption: str | None = None,
) -> Path:
    """Saves a preview grid for generated grayscale images."""
    _require_dependency(torch, "torch")
    _require_dependency(np, "numpy")
    _require_dependency(Image, "pillow")
    _require_dependency(make_grid, "torchvision")
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    images = denormalize(images.cpu())
    if nrow is None:
        nrow = max(1, int(np.sqrt(len(images))))
    grid = make_grid(images, nrow=nrow, padding=4)
    preview_array = grid.mul(255).clamp(0, 255).byte().permute(1, 2, 0).numpy()
    if preview_array.ndim == 3 and preview_array.shape[-1] == 1:
        preview_array = preview_array[..., 0]
    elif preview_array.ndim == 3 and preview_array.shape[-1] > 1:
        preview_array = preview_array[..., 0]
    image = Image.fromarray(preview_array, mode="L")
    image.save(output_path)
    if caption:
        output_path.with_suffix(".json").write_text(json.dumps({"caption": caption}, indent=2), encoding="utf-8")
    return output_path


def save_class_images(
    images: Any,
    label: int,
    output_root: str | Path,
    prefix: str = "sample",
    start_index: int = 0,
) -> list[Path]:
    """Saves generated samples inside a class-specific folder."""
    _require_dependency(Image, "pillow")
    class_dir = Path(output_root) / CLASS_NAMES[label]
    class_dir.mkdir(parents=True, exist_ok=True)
    images = denormalize(images.cpu())
    saved_paths: list[Path] = []
    for index, image in enumerate(images, start=start_index):
        output_path = class_dir / f"{prefix}_{index:04d}.png"
        Image.fromarray(image.squeeze(0).mul(255).clamp(0, 255).byte().numpy(), mode="L").save(output_path)
        saved_paths.append(output_path)
    return saved_paths


def save_json(data: dict[str, Any], output_path: str | Path) -> Path:
    """Writes small metadata files for review and debugging."""
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return output_path


def plot_loss_curve(losses: list[float], output_path: str | Path = LOSS_PLOT_PATH) -> Path:
    """Saves the loss curve generated during training."""
    _require_dependency(plt, "matplotlib")
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(8, 5))
    plt.plot(range(1, len(losses) + 1), losses, linewidth=2)
    plt.title("Conditional DDPM Training Loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()
    return output_path
