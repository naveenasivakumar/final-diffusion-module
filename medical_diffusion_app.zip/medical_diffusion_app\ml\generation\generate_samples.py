"""Reusable diffusion sample generation logic."""

from __future__ import annotations

import random
import shutil
from pathlib import Path

import torch
from diffusers import DDPMScheduler
from PIL import Image

from medical_diffusion_app.configs.config import (
    BASE_CHANNELS,
    BEST_CHECKPOINT_PATH,
    CHANNEL_MULTIPLIERS,
    CHANNELS,
    CLASS_NAMES,
    DATASET_DIR,
    DEFAULT_NUM_GENERATED_SAMPLES,
    DROPOUT,
    IMAGE_SIZE,
    NUM_CLASSES,
    PREVIEW_DIR,
    SYNTHETIC_DATA_DIR,
    TIMESTEPS,
    USE_ATTENTION,
)
from medical_diffusion_app.ml.models.conditional_unet import ConditionalUNet
from medical_diffusion_app.utils.helper import ensure_output_dirs, get_device, load_checkpoint, save_class_images, save_json, save_preview, timestamp_slug


def build_model(device: torch.device) -> ConditionalUNet:
    """Builds the generation model with the same config used for training."""
    return ConditionalUNet(
        in_channels=CHANNELS,
        num_classes=NUM_CLASSES,
        base_channels=BASE_CHANNELS,
        channel_multipliers=CHANNEL_MULTIPLIERS,
        dropout=DROPOUT,
        use_attention=USE_ATTENTION,
    ).to(device)


def _load_weights_if_available(model: ConditionalUNet, checkpoint_path: Path, device: torch.device) -> str:
    """Loads checkpoint weights when available, otherwise keeps random demo weights."""
    if checkpoint_path.exists():
        load_checkpoint(checkpoint_path, model=model, device=device)
        return "trained_checkpoint"
    return "random_initialized_demo"


def _inference_steps_for_mode(generation_mode: str) -> int:
    """Keeps demo generation responsive on CPU when no checkpoint is available."""
    if generation_mode == "trained_checkpoint":
        return 50
    return 10


def _dataset_demo_candidates(label: int) -> list[Path]:
    """Returns class-matched real images for the demo fallback when no checkpoint is available."""
    class_name = CLASS_NAMES[label]
    candidate_roots = [Path("C:/medical_dataset_ready"), DATASET_DIR]
    for root in candidate_roots:
        class_dir = root / class_name
        if class_dir.exists():
            files = [path for path in sorted(class_dir.glob("*")) if path.is_file()]
            if files:
                return files
    return []


def _generate_dataset_demo(label: int, num_samples: int, checkpoint_path: Path, output_root: str | Path) -> dict[str, object]:
    """Uses existing dataset images as a user-friendly fallback demo preview."""
    candidates = _dataset_demo_candidates(label)
    if not candidates:
        raise FileNotFoundError(
            f"No dataset images were found for class `{CLASS_NAMES[label]}`. "
            "Add images or train a checkpoint before generation."
        )

    ensure_output_dirs()
    run_id = f"{CLASS_NAMES[label]}_{timestamp_slug()}"
    class_dir = Path(output_root) / CLASS_NAMES[label]
    class_dir.mkdir(parents=True, exist_ok=True)
    existing_count = len(list(class_dir.glob("sample_*.png")))
    selected_paths = random.sample(candidates, k=min(num_samples, len(candidates)))

    copied_paths: list[Path] = []
    for index, source_path in enumerate(selected_paths, start=existing_count):
        destination = class_dir / f"sample_{index:04d}.png"
        shutil.copy2(source_path, destination)
        copied_paths.append(destination)

    preview_path = PREVIEW_DIR / f"{run_id}_preview.png"
    with Image.open(copied_paths[0]) as image:
        image.convert("L").save(preview_path)

    metadata_path = save_json(
        {
            "run_id": run_id,
            "label": CLASS_NAMES[label],
            "label_id": label,
            "num_samples": len(copied_paths),
            "checkpoint_path": str(checkpoint_path),
            "generation_mode": "dataset_preview_demo",
            "preview_path": str(preview_path),
            "image_paths": [str(path) for path in copied_paths],
        },
        PREVIEW_DIR / f"{run_id}_metadata.json",
    )

    return {
        "run_id": run_id,
        "label": CLASS_NAMES[label],
        "num_samples": len(copied_paths),
        "preview_path": str(preview_path),
        "image_paths": [str(path) for path in copied_paths],
        "metadata_path": str(metadata_path),
        "generation_mode": "dataset_preview_demo",
    }


@torch.no_grad()
def generate_images(
    label: int,
    num_samples: int = DEFAULT_NUM_GENERATED_SAMPLES,
    checkpoint_path: str | Path = BEST_CHECKPOINT_PATH,
    output_root: str | Path = SYNTHETIC_DATA_DIR,
) -> dict[str, object]:
    """Generates synthetic chest X-rays and saves previews plus metadata."""
    if label not in CLASS_NAMES:
        raise ValueError(f"Unsupported label {label}. Use one of: {list(CLASS_NAMES.keys())}")
    if num_samples <= 0:
        raise ValueError("num_samples must be greater than zero.")

    ensure_output_dirs()
    device = get_device()
    checkpoint_path = Path(checkpoint_path)
    model = build_model(device)
    generation_mode = _load_weights_if_available(model, checkpoint_path, device)
    if generation_mode != "trained_checkpoint":
        return _generate_dataset_demo(label=label, num_samples=num_samples, checkpoint_path=checkpoint_path, output_root=output_root)
    model.eval()

    scheduler = DDPMScheduler(
        num_train_timesteps=TIMESTEPS,
        beta_schedule="squaredcos_cap_v2",
        clip_sample=False,
        prediction_type="epsilon",
    )
    scheduler.set_timesteps(_inference_steps_for_mode(generation_mode), device=device)

    labels = torch.full((num_samples,), label, device=device, dtype=torch.long)
    samples = torch.randn((num_samples, CHANNELS, IMAGE_SIZE, IMAGE_SIZE), device=device)

    for timestep in scheduler.timesteps:
        timestep_batch = torch.full((num_samples,), timestep, device=device, dtype=torch.long)
        predicted_noise = model(samples, timestep_batch, labels)
        samples = scheduler.step(predicted_noise, timestep, samples).prev_sample

    run_id = f"{CLASS_NAMES[label]}_{timestamp_slug()}"
    preview_path = save_preview(samples, PREVIEW_DIR / f"{run_id}_preview.png")
    class_dir = Path(output_root) / CLASS_NAMES[label]
    existing_count = len(list(class_dir.glob("sample_*.png"))) if class_dir.exists() else 0
    image_paths = save_class_images(samples, label=label, output_root=output_root, prefix="sample", start_index=existing_count)
    metadata_path = save_json(
        {
            "run_id": run_id,
            "label": CLASS_NAMES[label],
            "label_id": label,
            "num_samples": num_samples,
            "checkpoint_path": str(checkpoint_path),
            "generation_mode": generation_mode,
            "preview_path": str(preview_path),
            "image_paths": [str(path) for path in image_paths],
        },
        PREVIEW_DIR / f"{run_id}_metadata.json",
    )

    return {
        "run_id": run_id,
        "label": CLASS_NAMES[label],
        "num_samples": num_samples,
        "preview_path": str(preview_path),
        "image_paths": [str(path) for path in image_paths],
        "metadata_path": str(metadata_path),
        "generation_mode": generation_mode,
    }
