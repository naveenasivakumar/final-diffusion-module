"""Generation page for requesting synthetic chest X-ray samples."""

from __future__ import annotations

from pathlib import Path

import streamlit as st

from medical_diffusion_app.configs.config import CLASS_NAMES


def _initialise_history() -> None:
    if "generation_history" not in st.session_state:
        st.session_state.generation_history = []


def _run_generation(label: int, num_samples: int) -> dict[str, object]:
    from medical_diffusion_app.ml.generation.generate_samples import generate_images
    return generate_images(label=label, num_samples=num_samples)


def render_generate_page() -> None:
    """Renders the generation controls, preview, and history."""
    _initialise_history()
    st.title("Generate Synthetic Chest X-Rays")

    label_name = st.selectbox("Disease label", options=list(CLASS_NAMES.values()))
    label = next(index for index, name in CLASS_NAMES.items() if name == label_name)
    num_samples = st.number_input("Sample count", min_value=1, max_value=16, value=4, step=1)

    if st.button("Generate", use_container_width=True):
        with st.spinner("Generating grayscale synthetic chest X-rays..."):
            try:
                result = _run_generation(label=label, num_samples=int(num_samples))
                st.session_state.generation_history.insert(0, result)
                st.success("Generation completed and outputs were saved.")
            except Exception as exc:
                st.error(f"Generation failed: {exc}")

    st.caption("If no trained checkpoint is available, the app falls back to a faster random demo generation mode.")

    from medical_diffusion_app.frontend.components.preview_card import render_preview_card

    latest = st.session_state.generation_history[0] if st.session_state.generation_history else None
    image_paths = latest.get("image_paths") if latest else None
    render_preview_card("Generated Preview", image_paths)

    st.markdown("### Generation history")
    if not st.session_state.generation_history:
        st.info("No generation history yet.")
        return

    for item in st.session_state.generation_history:
        st.markdown(
            f"- Label: `{item['label']}` | Samples: `{item['num_samples']}` | Mode: `{item['generation_mode']}`"
        )
