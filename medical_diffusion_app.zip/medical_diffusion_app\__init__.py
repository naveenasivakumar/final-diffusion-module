"""Medical diffusion application package."""
