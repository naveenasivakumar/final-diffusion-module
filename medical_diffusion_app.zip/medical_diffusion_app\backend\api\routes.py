"""FastAPI entry point exposing health, training, and generation routes."""

from __future__ import annotations

from fastapi import FastAPI, HTTPException

from medical_diffusion_app.backend.schemas.request_schema import GenerateRequest, TrainRequest
from medical_diffusion_app.backend.services.generation_service import build_health_payload, run_generation, run_training
from medical_diffusion_app.configs.config import PROJECT_TITLE


app = FastAPI(
    title=PROJECT_TITLE,
    version="1.0.0",
    description="Backend API for domain-adaptive synthetic chest X-ray generation.",
)


@app.get("/health")
def health() -> dict[str, object]:
    """Simple health endpoint used by Streamlit and quick checks."""
    return build_health_payload()


@app.post("/generate")
def generate(request: GenerateRequest) -> dict[str, object]:
    """Generates conditional diffusion samples for the selected disease class."""
    try:
        return run_generation(request)
    except ModuleNotFoundError as exc:
        raise HTTPException(
            status_code=503,
            detail=(
                f"Missing dependency: {exc.name or 'required package'}. "
                "Install ML dependencies with `pip install -r medical_diffusion_app/requirements-ml.txt`."
            ),
        ) from exc


@app.post("/train")
def train_model(request: TrainRequest) -> dict[str, object]:
    """Starts a small training run using the configured dataset."""
    try:
        return run_training(request)
    except ModuleNotFoundError as exc:
        raise HTTPException(
            status_code=503,
            detail=(
                f"Missing dependency: {exc.name or 'required package'}. "
                "Install ML dependencies with `pip install -r medical_diffusion_app/requirements-ml.txt`."
            ),
        ) from exc
