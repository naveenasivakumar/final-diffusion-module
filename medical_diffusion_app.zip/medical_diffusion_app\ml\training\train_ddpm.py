"""Training workflow for the conditional diffusion model."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import torch
from diffusers import DDPMScheduler
from torch import nn
from torch.optim import Adam
from torch.utils.data import DataLoader, Subset, WeightedRandomSampler, random_split

from medical_diffusion_app.configs.config import (
    BASE_CHANNELS,
    BATCH_SIZE,
    BEST_CHECKPOINT_PATH,
    CHANNEL_MULTIPLIERS,
    CHANNELS,
    DATASET_DIR,
    DROPOUT,
    EPOCHS,
    IMAGE_SIZE,
    LATEST_CHECKPOINT_PATH,
    LEARNING_RATE,
    LOSS_PLOT_PATH,
    MIXED_PRECISION,
    NUM_CLASSES,
    NUM_WORKERS,
    PREVIEW_DIR,
    SEED,
    TIMESTEPS,
    USE_ATTENTION,
    VAL_SPLIT,
    WEIGHT_DECAY,
)
from medical_diffusion_app.ml.data.dataset_loader import ChestXrayDataset
from medical_diffusion_app.ml.models.conditional_unet import ConditionalUNet
from medical_diffusion_app.utils.helper import ensure_output_dirs, get_device, load_checkpoint, plot_loss_curve, save_checkpoint, save_preview, set_seed


CPU_MAX_TRAIN_BATCHES = 8
CPU_MAX_VAL_BATCHES = 2
CPU_PREVIEW_TIMESTEPS = 10


def build_model(device: torch.device) -> ConditionalUNet:
    """Builds the conditional U-Net used for training and resume flows."""
    return ConditionalUNet(
        in_channels=CHANNELS,
        num_classes=NUM_CLASSES,
        base_channels=BASE_CHANNELS,
        channel_multipliers=CHANNEL_MULTIPLIERS,
        dropout=DROPOUT,
        use_attention=USE_ATTENTION,
    ).to(device)


def create_scheduler() -> DDPMScheduler:
    """Creates the scheduler shared by training and validation."""
    return DDPMScheduler(
        num_train_timesteps=TIMESTEPS,
        beta_schedule="squaredcos_cap_v2",
        clip_sample=False,
        prediction_type="epsilon",
    )


def build_weighted_sampler(dataset: ChestXrayDataset, subset: Subset) -> WeightedRandomSampler:
    """Improves class balance for rare disease classes during training."""
    labels = [dataset.samples[index][1] for index in subset.indices]
    class_counts = torch.bincount(torch.tensor(labels), minlength=NUM_CLASSES).float()
    class_counts[class_counts == 0] = 1.0
    class_weights = 1.0 / class_counts
    sample_weights = class_weights[torch.tensor(labels)]
    return WeightedRandomSampler(sample_weights.double(), len(sample_weights), replacement=True)


def create_dataloaders(dataset_path: str | Path) -> tuple[DataLoader, DataLoader]:
    """Builds train and validation dataloaders."""
    dataset = ChestXrayDataset(dataset_path, image_size=IMAGE_SIZE)
    val_size = max(1, int(len(dataset) * VAL_SPLIT))
    train_size = len(dataset) - val_size
    if train_size <= 0:
        raise ValueError("Dataset is too small to split into train and validation sets.")

    train_subset, val_subset = random_split(
        dataset,
        [train_size, val_size],
        generator=torch.Generator().manual_seed(SEED),
    )
    train_loader = DataLoader(
        train_subset,
        batch_size=BATCH_SIZE,
        sampler=build_weighted_sampler(dataset, train_subset),
        num_workers=NUM_WORKERS,
        pin_memory=torch.cuda.is_available(),
    )
    val_loader = DataLoader(
        val_subset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=NUM_WORKERS,
        pin_memory=torch.cuda.is_available(),
    )
    return train_loader, val_loader


def _autocast(device: torch.device, enabled: bool):
    """Returns a compatible autocast context."""
    if hasattr(torch, "amp") and hasattr(torch.amp, "autocast"):
        return torch.amp.autocast(device_type=device.type, enabled=enabled)
    return torch.autocast(device_type=device.type, enabled=enabled)


def _grad_scaler(device: torch.device, enabled: bool):
    """Returns a compatible gradient scaler."""
    if hasattr(torch, "amp") and hasattr(torch.amp, "GradScaler"):
        return torch.amp.GradScaler(device.type, enabled=enabled)
    return torch.cuda.amp.GradScaler(enabled=enabled)


@torch.no_grad()
def save_preview_images(
    model: nn.Module,
    scheduler: DDPMScheduler,
    device: torch.device,
    output_path: str | Path,
    num_per_class: int = 2,
) -> Path:
    """Generates compact preview samples after each epoch."""
    model.eval()
    labels = torch.tensor([label for label in range(NUM_CLASSES) for _ in range(num_per_class)], device=device, dtype=torch.long)
    samples = torch.randn((len(labels), CHANNELS, IMAGE_SIZE, IMAGE_SIZE), device=device)

    preview_steps = CPU_PREVIEW_TIMESTEPS if device.type == "cpu" else TIMESTEPS
    scheduler.set_timesteps(preview_steps, device=device)
    for timestep in scheduler.timesteps:
        timestep_batch = torch.full((len(labels),), timestep, device=device, dtype=torch.long)
        predicted_noise = model(samples, timestep_batch, labels)
        samples = scheduler.step(predicted_noise, timestep, samples).prev_sample

    return save_preview(samples, output_path, nrow=num_per_class, caption="Validation preview generated after training epoch.")


@torch.no_grad()
def validate(model: nn.Module, val_loader: DataLoader, scheduler: DDPMScheduler, device: torch.device) -> float:
    """Computes validation loss on noisy chest X-ray batches."""
    model.eval()
    criterion = nn.MSELoss()
    losses: list[float] = []
    max_batches = CPU_MAX_VAL_BATCHES if device.type == "cpu" else None
    for batch_index, (clean_images, labels) in enumerate(val_loader, start=1):
        clean_images = clean_images.to(device)
        labels = labels.to(device, dtype=torch.long)
        noise = torch.randn_like(clean_images)
        timesteps = torch.randint(0, scheduler.config.num_train_timesteps, (clean_images.size(0),), device=device, dtype=torch.long)
        noisy_images = scheduler.add_noise(clean_images, noise, timesteps)
        predicted_noise = model(noisy_images, timesteps, labels)
        losses.append(criterion(predicted_noise, noise).item())
        if max_batches is not None and batch_index >= max_batches:
            break
    return float(sum(losses) / max(len(losses), 1))


def train(
    dataset_path: str | Path = DATASET_DIR,
    epochs: int = EPOCHS,
    resume_from: str | Path | None = None,
) -> dict[str, Any]:
    """Runs the conditional DDPM training workflow."""
    ensure_output_dirs()
    set_seed(SEED)
    device = get_device()
    train_loader, val_loader = create_dataloaders(dataset_path)
    model = build_model(device)
    scheduler = create_scheduler()
    optimizer = Adam(model.parameters(), lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY)

    use_amp = MIXED_PRECISION and device.type == "cuda"
    scaler = _grad_scaler(device, use_amp)
    criterion = nn.MSELoss()
    start_epoch = 1
    best_val_loss = float("inf")
    history: list[float] = []

    if resume_from is not None:
        checkpoint = load_checkpoint(resume_from, model=model, optimizer=optimizer, device=device, scaler=scaler)
        start_epoch = int(checkpoint.get("epoch", 0)) + 1
        best_val_loss = float(checkpoint.get("best_val_loss", checkpoint.get("loss", float("inf"))))
        history = list(checkpoint.get("history", []))

    for epoch in range(start_epoch, epochs + 1):
        model.train()
        running_loss = 0.0
        max_batches = CPU_MAX_TRAIN_BATCHES if device.type == "cpu" else None
        batches_processed = 0
        for batch_index, (clean_images, labels) in enumerate(train_loader, start=1):
            clean_images = clean_images.to(device)
            labels = labels.to(device, dtype=torch.long)
            noise = torch.randn_like(clean_images)
            timesteps = torch.randint(0, scheduler.config.num_train_timesteps, (clean_images.size(0),), device=device, dtype=torch.long)
            noisy_images = scheduler.add_noise(clean_images, noise, timesteps)

            optimizer.zero_grad(set_to_none=True)
            with _autocast(device, use_amp):
                predicted_noise = model(noisy_images, timesteps, labels)
                loss = criterion(predicted_noise, noise)

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            running_loss += loss.item()
            batches_processed = batch_index
            if max_batches is not None and batch_index >= max_batches:
                break

        epoch_loss = running_loss / max(batches_processed, 1)
        val_loss = validate(model, val_loader, scheduler, device)
        history.append(epoch_loss)
        print(
            f"Epoch {epoch}/{epochs} complete | "
            f"train_loss={epoch_loss:.4f} | val_loss={val_loss:.4f} | device={device.type}"
        )

        current_best = min(best_val_loss, val_loss)
        save_checkpoint(
            checkpoint_path=LATEST_CHECKPOINT_PATH,
            model=model,
            optimizer=optimizer,
            epoch=epoch,
            loss=val_loss,
            best_val_loss=current_best,
            history=history,
            scaler=scaler,
            extra_state={"dataset_path": str(dataset_path)},
        )
        save_preview_images(model, scheduler, device, PREVIEW_DIR / f"epoch_{epoch:03d}.png")

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            save_checkpoint(
                checkpoint_path=BEST_CHECKPOINT_PATH,
                model=model,
                optimizer=optimizer,
                epoch=epoch,
                loss=val_loss,
                best_val_loss=best_val_loss,
                history=history,
                scaler=scaler,
                extra_state={"dataset_path": str(dataset_path)},
            )

    plot_loss_curve(history)
    return {
        "dataset_path": str(Path(dataset_path)),
        "epochs": epochs,
        "best_checkpoint": str(BEST_CHECKPOINT_PATH),
        "latest_checkpoint": str(LATEST_CHECKPOINT_PATH),
        "best_val_loss": float(best_val_loss),
        "loss_plot": str(LOSS_PLOT_PATH),
        "completed_epochs": len(history),
    }

