"""Pydantic request schemas used by the FastAPI routes."""

from __future__ import annotations

from pydantic import BaseModel, Field


class GenerateRequest(BaseModel):
    """Request body for synthetic image generation."""

    label: int = Field(..., ge=0, le=5, description="Disease label id")
    num_samples: int = Field(default=4, ge=1, le=16, description="Number of images to generate")


class TrainRequest(BaseModel):
    """Request body for training the conditional DDPM model."""

    dataset_path: str | None = Field(default=None, description="Optional custom dataset directory")
    epochs: int = Field(default=1, ge=1, le=100, description="Number of training epochs")
