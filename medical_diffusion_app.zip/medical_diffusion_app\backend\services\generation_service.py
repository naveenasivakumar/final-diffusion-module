"""Service layer that keeps API routes thin and readable."""

from __future__ import annotations

from pathlib import Path

from medical_diffusion_app.backend.schemas.request_schema import GenerateRequest, TrainRequest
from medical_diffusion_app.configs.config import (
    API_BASE_URL,
    BEST_CHECKPOINT_PATH,
    CLASS_NAMES,
    DATASET_DIR,
    EFFICIENTNET_BACKBONE,
    GRADCAM_TARGET_LAYER,
    PROJECT_TITLE,
)


def _safe_device_name() -> str:
    """Returns a compact device label without requiring torch at import time."""
    try:
        import torch
    except ModuleNotFoundError:
        return "cpu (torch not installed)"
    return "cuda" if torch.cuda.is_available() else "cpu"


def _ensure_outputs() -> None:
    """Creates output directories without pulling in optional ML imports."""
    from medical_diffusion_app.configs.config import CHECKPOINT_DIR, LOG_DIR, PREVIEW_DIR, SYNTHETIC_DATA_DIR

    for folder in (CHECKPOINT_DIR, PREVIEW_DIR, SYNTHETIC_DATA_DIR, LOG_DIR):
        folder.mkdir(parents=True, exist_ok=True)


def build_health_payload() -> dict[str, object]:
    """Returns a small health summary for the UI and API checks."""
    _ensure_outputs()
    return {
        "status": "ok",
        "project": PROJECT_TITLE,
        "device": _safe_device_name(),
        "backend_url": API_BASE_URL,
        "checkpoint_available": Path(BEST_CHECKPOINT_PATH).exists(),
        "efficientnet_ready": EFFICIENTNET_BACKBONE,
        "gradcam_ready": GRADCAM_TARGET_LAYER,
    }


def run_generation(request: GenerateRequest) -> dict[str, object]:
    """Runs label-conditioned sample generation through the ML layer."""
    from medical_diffusion_app.ml.generation.generate_samples import generate_images

    result = generate_images(label=request.label, num_samples=request.num_samples)
    result["class_map"] = CLASS_NAMES
    return result


def run_training(request: TrainRequest) -> dict[str, object]:
    """Runs training with a clean interface for the API layer."""
    from medical_diffusion_app.ml.training.train_ddpm import train

    dataset_path = Path(request.dataset_path) if request.dataset_path else DATASET_DIR
    result = train(dataset_path=dataset_path, epochs=request.epochs)
    result["efficientnet_ready"] = EFFICIENTNET_BACKBONE
    result["gradcam_ready"] = GRADCAM_TARGET_LAYER
    return result
