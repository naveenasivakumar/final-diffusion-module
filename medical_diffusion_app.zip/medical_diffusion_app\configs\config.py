"""Central configuration for the medical diffusion application."""

from __future__ import annotations

from pathlib import Path


PROJECT_TITLE = "Domain-Adaptive Synthetic Data Generation for Rare Disease Chest X-Ray Classification Using Conditional Diffusion Models"
PROJECT_ROOT = Path(__file__).resolve().parent.parent

API_HOST = "127.0.0.1"
API_PORT = 8000
API_BASE_URL = f"http://{API_HOST}:{API_PORT}"

DATASET_DIR = PROJECT_ROOT / "dataset"
DATASET_PATH = DATASET_DIR
CLASS_NAMES = {
    0: "normal",
    1: "pleural_effusion",
    2: "cardiomegaly",
    3: "pneumonia",
    4: "atelectasis",
    5: "consolidation",
}
CLASS_TO_LABEL = {name: idx for idx, name in CLASS_NAMES.items()}
VALID_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}

IMAGE_SIZE = 256
CHANNELS = 1
NUM_CLASSES = len(CLASS_NAMES)
BASE_CHANNELS = 64
CHANNEL_MULTIPLIERS = (1, 2, 4, 8)
DROPOUT = 0.1
USE_ATTENTION = True
TIMESTEPS = 1000

BATCH_SIZE = 8
EPOCHS = 100
LEARNING_RATE = 1e-4
WEIGHT_DECAY = 1e-5
VAL_SPLIT = 0.1
NUM_WORKERS = 0
MIXED_PRECISION = True
SEED = 42
ENABLE_TENSORBOARD = False

EFFICIENTNET_BACKBONE = "efficientnet-b0-ready"
GRADCAM_TARGET_LAYER = "ml.models.conditional_unet.ConditionalUNet.output_conv"

OUTPUTS_DIR = Path.home() / "AppData" / "Local" / "Temp" / "medical_diffusion_outputs"
CHECKPOINT_DIR = OUTPUTS_DIR / "checkpoints"
PREVIEW_DIR = OUTPUTS_DIR / "previews"
SYNTHETIC_DATA_DIR = OUTPUTS_DIR / "synthetic_data"
LOG_DIR = OUTPUTS_DIR / "logs"
BEST_CHECKPOINT_PATH = CHECKPOINT_DIR / "conditional_ddpm_best.pt"
LATEST_CHECKPOINT_PATH = CHECKPOINT_DIR / "conditional_ddpm_latest.pt"
LOSS_PLOT_PATH = LOG_DIR / "loss_curve.png"

DEFAULT_NUM_GENERATED_SAMPLES = 16
