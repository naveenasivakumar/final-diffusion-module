"""Frontend pages package."""
