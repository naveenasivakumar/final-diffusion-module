"""Preview card component for displaying generated chest X-ray images."""

from __future__ import annotations

from pathlib import Path

import streamlit as st


def render_preview_card(title: str, image_paths: list[str] | str | None, caption: str = "") -> None:
    """Renders all generated images in a grid."""
    st.markdown(f"### {title}")
    paths: list[str] = []
    if isinstance(image_paths, list):
        paths = [p for p in image_paths if Path(p).exists()]
    elif isinstance(image_paths, str) and Path(image_paths).exists():
        paths = [image_paths]
    if not paths:
        st.info("No preview available yet. Generate images to see results here.")
        return
    for path in paths:
        st.image(path, caption=Path(path).name, width=400)
