"""Sidebar helpers for the Streamlit frontend."""

from __future__ import annotations

import streamlit as st

from medical_diffusion_app.configs.config import API_BASE_URL, PROJECT_TITLE


def render_sidebar() -> str:
    """Renders sidebar navigation and returns the selected page."""
    st.sidebar.title("Medical Diffusion App")
    st.sidebar.caption(PROJECT_TITLE)
    st.sidebar.markdown("---")
    page = st.sidebar.radio("Navigation", options=["Home", "Generate"], index=0)
    st.sidebar.markdown("---")
    st.sidebar.info(f"Backend API: `{API_BASE_URL}`")
    return page

