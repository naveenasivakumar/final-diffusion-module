"""Streamlit entry point for the medical diffusion application."""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st


PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from medical_diffusion_app.frontend.components.sidebar import render_sidebar
from medical_diffusion_app.frontend.pages.generate import render_generate_page
from medical_diffusion_app.frontend.pages.home import render_home_page


st.set_page_config(page_title="Medical Diffusion App", page_icon=":hospital:", layout="wide")


def main() -> None:
    """Routes to the selected Streamlit page."""
    page = render_sidebar()
    if page == "Home":
        render_home_page()
    else:
        render_generate_page()


if __name__ == "__main__":
    main()

