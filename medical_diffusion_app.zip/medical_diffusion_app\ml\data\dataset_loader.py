"""Dataset loader for class-wise grayscale chest X-ray folders."""

from __future__ import annotations

from pathlib import Path
from typing import Callable

from PIL import Image
from torch import Tensor
from torch.utils.data import Dataset
from torchvision import transforms

from medical_diffusion_app.configs.config import CLASS_TO_LABEL, IMAGE_SIZE, VALID_IMAGE_EXTENSIONS


class ChestXrayDataset(Dataset):
    """Loads chest X-ray images from folders named by disease label."""

    def __init__(self, root_dir: str | Path, image_size: int = IMAGE_SIZE, transform: Callable | None = None) -> None:
        self.root_dir = Path(root_dir)
        if not self.root_dir.exists():
            raise FileNotFoundError(f"Dataset path does not exist: {self.root_dir}")

        self.transform = transform or self._build_default_transform(image_size)
        self.samples = self._collect_samples()
        if not self.samples:
            raise RuntimeError(
                "No chest X-ray images were found. Create class folders named "
                "`normal`, `pleural_effusion`, `cardiomegaly`, `pneumonia`, "
                "`atelectasis`, and `consolidation` inside the dataset directory."
            )

    def _build_default_transform(self, image_size: int) -> transforms.Compose:
        return transforms.Compose(
            [
                transforms.Resize((image_size, image_size)),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.5], std=[0.5]),
            ]
        )

    def _collect_samples(self) -> list[tuple[Path, int]]:
        samples: list[tuple[Path, int]] = []
        for class_name, label in CLASS_TO_LABEL.items():
            class_dir = self.root_dir / class_name
            if not class_dir.exists():
                continue
            for image_path in sorted(class_dir.rglob("*")):
                if image_path.is_file() and image_path.suffix.lower() in VALID_IMAGE_EXTENSIONS:
                    samples.append((image_path, label))
        return samples

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, index: int) -> tuple[Tensor, int]:
        image_path, label = self.samples[index]
        with Image.open(image_path) as image:
            image = image.convert("L")
            tensor = self.transform(image)
        return tensor, label
