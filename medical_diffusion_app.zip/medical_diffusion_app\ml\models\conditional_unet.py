"""Conditional U-Net used for label-guided chest X-ray diffusion."""

from __future__ import annotations

import math

import torch
import torch.nn.functional as F
from torch import Tensor, nn


class SinusoidalPositionEmbeddings(nn.Module):
    """Encodes diffusion timesteps with sinusoidal embeddings."""

    def __init__(self, dim: int) -> None:
        super().__init__()
        self.dim = dim

    def forward(self, timesteps: Tensor) -> Tensor:
        device = timesteps.device
        half_dim = self.dim // 2
        scale = math.log(10000) / max(half_dim - 1, 1)
        embedding = torch.exp(torch.arange(half_dim, device=device) * -scale)
        embedding = timesteps.float()[:, None] * embedding[None, :]
        embedding = torch.cat((embedding.sin(), embedding.cos()), dim=-1)
        if self.dim % 2 == 1:
            embedding = F.pad(embedding, (0, 1))
        return embedding


class ResidualBlock(nn.Module):
    """Residual block modulated by time and label conditioning."""

    def __init__(self, in_channels: int, out_channels: int, cond_dim: int, dropout: float = 0.0) -> None:
        super().__init__()
        self.norm1 = nn.GroupNorm(num_groups=8, num_channels=in_channels)
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1)
        self.cond_proj = nn.Sequential(nn.SiLU(), nn.Linear(cond_dim, out_channels * 2))
        self.norm2 = nn.GroupNorm(num_groups=8, num_channels=out_channels)
        self.dropout = nn.Dropout(dropout)
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1)
        self.skip = nn.Conv2d(in_channels, out_channels, kernel_size=1) if in_channels != out_channels else nn.Identity()

    def forward(self, x: Tensor, cond: Tensor) -> Tensor:
        residual = self.skip(x)
        hidden = self.conv1(F.silu(self.norm1(x)))
        scale, shift = self.cond_proj(cond).chunk(2, dim=1)
        hidden = self.norm2(hidden)
        hidden = hidden * (1 + scale[:, :, None, None]) + shift[:, :, None, None]
        hidden = self.conv2(self.dropout(F.silu(hidden)))
        return hidden + residual


class AttentionBlock(nn.Module):
    """Simple spatial attention for higher-level latent features."""

    def __init__(self, channels: int) -> None:
        super().__init__()
        self.norm = nn.GroupNorm(num_groups=8, num_channels=channels)
        self.qkv = nn.Conv1d(channels, channels * 3, kernel_size=1)
        self.proj = nn.Conv1d(channels, channels, kernel_size=1)

    def forward(self, x: Tensor) -> Tensor:
        batch_size, channels, height, width = x.shape
        hidden = self.norm(x).view(batch_size, channels, height * width)
        query, key, value = self.qkv(hidden).chunk(3, dim=1)
        attention = torch.softmax(torch.bmm(query.transpose(1, 2), key) * (channels ** -0.5), dim=-1)
        output = torch.bmm(value, attention.transpose(1, 2))
        return x + self.proj(output).view(batch_size, channels, height, width)


class Downsample(nn.Module):
    """Reduces spatial resolution by 2x."""

    def __init__(self, channels: int) -> None:
        super().__init__()
        self.conv = nn.Conv2d(channels, channels, kernel_size=4, stride=2, padding=1)

    def forward(self, x: Tensor) -> Tensor:
        return self.conv(x)


class Upsample(nn.Module):
    """Increases spatial resolution by 2x."""

    def __init__(self, channels: int) -> None:
        super().__init__()
        self.conv = nn.Conv2d(channels, channels, kernel_size=3, padding=1)

    def forward(self, x: Tensor) -> Tensor:
        return self.conv(F.interpolate(x, scale_factor=2.0, mode="nearest"))


class ConditionalUNet(nn.Module):
    """Conditional U-Net for grayscale rare disease chest X-ray synthesis."""

    def __init__(
        self,
        in_channels: int = 1,
        num_classes: int = 3,
        base_channels: int = 64,
        channel_multipliers: tuple[int, ...] = (1, 2, 4, 8),
        dropout: float = 0.1,
        use_attention: bool = True,
    ) -> None:
        super().__init__()
        cond_dim = base_channels * 4
        self.input_conv = nn.Conv2d(in_channels, base_channels, kernel_size=3, padding=1)
        self.time_embedding = nn.Sequential(
            SinusoidalPositionEmbeddings(base_channels),
            nn.Linear(base_channels, cond_dim),
            nn.SiLU(),
            nn.Linear(cond_dim, cond_dim),
        )
        self.label_embedding = nn.Embedding(num_classes, cond_dim)

        self.down_blocks = nn.ModuleList()
        self.skip_channels: list[int] = []
        current_channels = base_channels
        for level, multiplier in enumerate(channel_multipliers):
            out_channels = base_channels * multiplier
            block1 = ResidualBlock(current_channels, out_channels, cond_dim, dropout)
            block2 = ResidualBlock(out_channels, out_channels, cond_dim, dropout)
            attn = AttentionBlock(out_channels) if use_attention and level >= 2 else nn.Identity()
            down = Downsample(out_channels) if level < len(channel_multipliers) - 1 else nn.Identity()
            self.down_blocks.append(nn.ModuleList([block1, block2, attn, down]))
            self.skip_channels.append(out_channels)
            current_channels = out_channels

        self.mid_block1 = ResidualBlock(current_channels, current_channels, cond_dim, dropout)
        self.mid_attn = AttentionBlock(current_channels) if use_attention else nn.Identity()
        self.mid_block2 = ResidualBlock(current_channels, current_channels, cond_dim, dropout)

        self.up_blocks = nn.ModuleList()
        for level, multiplier in reversed(list(enumerate(channel_multipliers))):
            skip_channels = self.skip_channels[level]
            out_channels = base_channels * multiplier
            block1 = ResidualBlock(current_channels + skip_channels, out_channels, cond_dim, dropout)
            block2 = ResidualBlock(out_channels, out_channels, cond_dim, dropout)
            attn = AttentionBlock(out_channels) if use_attention and level >= 2 else nn.Identity()
            up = Upsample(out_channels) if level > 0 else nn.Identity()
            self.up_blocks.append(nn.ModuleList([block1, block2, attn, up]))
            current_channels = out_channels

        self.output_norm = nn.GroupNorm(num_groups=8, num_channels=current_channels)
        self.output_conv = nn.Conv2d(current_channels, in_channels, kernel_size=3, padding=1)

    def forward(self, x: Tensor, timesteps: Tensor, labels: Tensor) -> Tensor:
        cond = self.time_embedding(timesteps) + self.label_embedding(labels)
        hidden = self.input_conv(x)
        skip_connections: list[Tensor] = []

        for block1, block2, attn, down in self.down_blocks:
            hidden = block1(hidden, cond)
            hidden = block2(hidden, cond)
            hidden = attn(hidden)
            skip_connections.append(hidden)
            hidden = down(hidden)

        hidden = self.mid_block1(hidden, cond)
        hidden = self.mid_attn(hidden)
        hidden = self.mid_block2(hidden, cond)

        for block1, block2, attn, up in self.up_blocks:
            skip = skip_connections.pop()
            if hidden.shape[-2:] != skip.shape[-2:]:
                hidden = F.interpolate(hidden, size=skip.shape[-2:], mode="nearest")
            hidden = torch.cat([hidden, skip], dim=1)
            hidden = block1(hidden, cond)
            hidden = block2(hidden, cond)
            hidden = attn(hidden)
            hidden = up(hidden)

        return self.output_conv(F.silu(self.output_norm(hidden)))
